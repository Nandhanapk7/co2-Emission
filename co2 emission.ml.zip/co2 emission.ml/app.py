import streamlit as st
import pickle
import numpy as np
import pandas as pd

# Load the trained model
MODEL_PATH = r"C:\\Users\\HP\\Desktop\\Project\\co2 emission.ml\\RondomforestRegressor_model.pkl"
with open(MODEL_PATH, 'rb') as model_file:
    model = pickle.load(model_file)

# Load LabelEncoder and Scaler objects
ENCODER_PATH = r"C:\\Users\\HP\\Desktop\\Project\\co2 emission.ml\\encoed.pkl"
SCALER_PATH = r"C:\\Users\\HP\\Desktop\\Project\\co2 emission.ml\\scaler.pkl"
with open(ENCODER_PATH, 'rb') as enc_file:
    encoders = pickle.load(enc_file)  # This should be a dictionary of LabelEncoders
with open(SCALER_PATH, 'rb') as scaler_file:
    scaler = pickle.load(scaler_file)  # StandardScaler object

# Load the dataset for dropdown options (use your actual dataset path)
data = pd.read_csv(r"C:\\Users\\HP\\Desktop\\Project\\co2 emission.ml\\co2.csv")

# Streamlit App
st.title("Vehicle CO2 Emission Prediction App")
st.write("Provide the details below to get a CO2 emission prediction.")

# Input fields
make = st.selectbox('Make', data['Make'].unique())
model_car = st.selectbox('Model', data['Model'].unique())
vehicle_class = st.selectbox('Vehicle Class', data['Vehicle Class'].unique())
engine_size = st.number_input('Engine Size (L)', min_value=0.0, step=0.1)
cylinders = st.number_input('Cylinders', min_value=0, step=1)
transmission = st.selectbox('Transmission', data['Transmission'].unique())
fuel_type = st.selectbox('Fuel Type', data['Fuel Type'].unique())
fuel_consumption_city = st.number_input('Fuel Consumption City (L/100 km)', min_value=0.0, step=0.1)
fuel_consumption_hwy = st.number_input('Fuel Consumption Hwy (L/100 km)', min_value=0.0, step=0.1)
fuel_consumption_comb = st.number_input('Fuel Consumption Comb (L/100 km)', min_value=0.0, step=0.1)
fuel_consumption_comb_mpg = st.number_input('Fuel Consumption Comb (mpg)', min_value=0.0, step=0.1)

# Prediction button
if st.button("Predict"):
    try:
        # Encode categorical inputs using preloaded encoders
        make_encoded = encoders['Make'].transform([make])[0]
        model_car_encoded = encoders['Model'].transform([model_car])[0]
        vehicle_class_encoded = encoders['Vehicle Class'].transform([vehicle_class])[0]
        transmission_encoded = encoders['Transmission'].transform([transmission])[0]
        fuel_type_encoded = encoders['Fuel Type'].transform([fuel_type])[0]

        # Prepare the input data
        input_data = np.array([[make_encoded, model_car_encoded, vehicle_class_encoded, engine_size, cylinders,
                                transmission_encoded, fuel_type_encoded, fuel_consumption_city,
                                fuel_consumption_hwy, fuel_consumption_comb, fuel_consumption_comb_mpg]])
        
        # Scale the input data
        input_data_scaled = scaler.transform(input_data)

        # Predict
        prediction = model.predict(input_data_scaled)

        # Display prediction result
        st.success(f"The predicted CO2 emissions are: {prediction[0]:.2f} g/km")
    except Exception as e:
        st.error(f"Error occurred: {str(e)}")
